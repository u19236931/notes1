export class Course {
    courseId: Number = 0;
    name:String = "";
    duration:String = "";
    description:String = "";
}

